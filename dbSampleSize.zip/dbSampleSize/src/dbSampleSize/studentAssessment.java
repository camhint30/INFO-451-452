package dbSampleSize;

public class studentAssessment {
	
	int  idAssessment, idStudent, dateSubmitted, isBanked, score;

	public studentAssessment(int idAssessment, int idStudent,
			int dateSubmitted,int isBanked, int score) {
		super();
		this.idAssessment = idAssessment;
		this.idStudent = idStudent;
		this.dateSubmitted = dateSubmitted;
		this.isBanked = isBanked;
		this.score = score;
	}

	public int getIdAssessment() {
		return idAssessment;
	}

	public void setIdAssessment(int idAssessment) {
		this.idAssessment = idAssessment;
	}

	public int getIdStudent() {
		return idStudent;
	}

	public void setIdStudent(int idStudent) {
		this.idStudent = idStudent;
	}

	public int getDateSubmitted() {
		return dateSubmitted;
	}

	public void setDateSubmitted(int dateSubmitted) {
		this.dateSubmitted = dateSubmitted;
	}

	public int getIsBanked() {
		return isBanked;
	}

	public void setIsBanked(int isBanked) {
		this.isBanked = isBanked;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "studentAssessment [idAssessment=" + idAssessment + ", idStudent=" + idStudent + ", dateSubmitted="
				+ dateSubmitted + ", isBanked=" + isBanked + ", score=" + score + "]";
	}
	
	
}
