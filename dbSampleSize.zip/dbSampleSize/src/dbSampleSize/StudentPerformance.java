package dbSampleSize;

public class StudentPerformance {

	int id, mathScore, readScore, writeScore;
	String gender, race, education, lunch, prepCourse;
	public StudentPerformance(int id, String gender, String race,
			String education, String lunch, String prepCourse, int mathScore, int readScore, int writeScore) {
		super();
		this.id = id;
		this.mathScore = mathScore;
		this.readScore = readScore;
		this.writeScore = writeScore;
		this.gender = gender;
		this.race = race;
		this.education = education;
		this.lunch = lunch;
		this.prepCourse = prepCourse;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMathScore() {
		return mathScore;
	}
	public void setMathScore(int mathScore) {
		this.mathScore = mathScore;
	}
	public int getReadScore() {
		return readScore;
	}
	public void setReadScore(int readScore) {
		this.readScore = readScore;
	}
	public int getWriteScore() {
		return writeScore;
	}
	public void setWriteScore(int writeScore) {
		this.writeScore = writeScore;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRace() {
		return race;
	}
	public void setRace(String race) {
		this.race = race;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getLunch() {
		return lunch;
	}
	public void setLunch(String lunch) {
		this.lunch = lunch;
	}
	public String getPrepCourse() {
		return prepCourse;
	}
	public void setPrepCourse(String prepCourse) {
		this.prepCourse = prepCourse;
	}
	@Override
	public String toString() {
		return "StudentPerformance [id=" + id + ", mathScore=" + mathScore + ", readScore=" + readScore
				+ ", writeScore=" + writeScore + ", gender=" + gender + ", race=" + race + ", education=" + education
				+ ", lunch=" + lunch + ", prepCourse=" + prepCourse + "]";
	}
	
	
	
}
