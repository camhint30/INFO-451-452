package dbSampleSize;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 * @param args
 * 	This program is giving 4 ways to get a sample size from csv file. 
 */
/**
 * Enjoyed group dealing with the issue are:
 * 
 * @author Sameer, Camereon,Kyler, Justin
 *
 */

public class sampleSize {
	static Random rand = new Random();
	static int population;
	static int max;
	static int min = 0;
	static int samplesie;

	static ArrayList<StudentPerformance> studentPerList = new ArrayList<StudentPerformance>();
	static ArrayList<studentAssessment> studentAss = new ArrayList<studentAssessment>();

	public static void main(String[] args) {
		File smallFile = new File("src/dbSampleSize/SampleSize/StudentsPerformance.csv");
		File bigFile = new File("src/dbSampleSize/SampleSize/studentAssessment.csv");

		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String databaseInput[] = new String[2000];
		@SuppressWarnings("unused")
		String input[] = new String[20000];
		BufferedReader brr = null;
		String linee = "";
		String cvsSplitByy = ",";
		String databaseInputt[] = new String[200000];
		@SuppressWarnings("unused")
		String inputt[] = new String[2000000];

		try {
			br = new BufferedReader(new FileReader(smallFile));
			while ((line = br.readLine()) != null) {
				databaseInput = line.split(cvsSplitBy);
				StudentPerformance sp = new StudentPerformance(Integer.parseInt(databaseInput[0]), databaseInput[1],
						databaseInput[2], databaseInput[3], databaseInput[4], databaseInput[5],
						Integer.parseInt(databaseInput[6]), Integer.parseInt(databaseInput[7]),
						Integer.parseInt(databaseInput[8]));
				studentPerList.add(sp);
			}
		} catch (Exception e) {

		}

		try {
			brr = new BufferedReader(new FileReader(bigFile));
			while ((linee = brr.readLine()) != null) {
				databaseInputt = linee.split(cvsSplitByy);
				studentAssessment spp = null;
				if (databaseInputt.length == 4) {
					spp = new studentAssessment(Integer.parseInt("-1"), Integer.parseInt("-1"), Integer.parseInt("-1"),
							Integer.parseInt("-1"), Integer.parseInt("-1"));
				} else {
					spp = new studentAssessment(Integer.parseInt(databaseInputt[0]),
							Integer.parseInt(databaseInputt[1]), Integer.parseInt(databaseInputt[2]),
							Integer.parseInt(databaseInputt[3]), Integer.parseInt(databaseInputt[4]));
				}
				studentAss.add(spp);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		// write your method for the small file here:
		dbJavaA(studentPerList);
		dbJavaC(studentPerList, 50);
		System.out.println("***************************************************************");
		System.out.println("********" + " Kyler's Code start here here: " + "**************");
		System.out.println("***************************************************************");
		dbJavaE(studentPerList, 50);
		System.out.println("***************************************************************");
		System.out.println("********" + " Kyler's Code Ends here here: " + "**************");
		System.out.println("***************************************************************");
		System.out.println(" @@@@@@@@@@@@@@@@@@@@@@ ");
		System.out.println(" Small file Ends Here ");
		System.out.println(" @@@@@@@@@@@@@@@@@@@@@@ ");

		// write your method for the big file here:
		dbJavaB(studentAss);
		dbJavaD(studentAss, 2000);
		System.out.println("***************************************************************");
		System.out.println("********" + " Kyler's Code start here here: " + "**************");
		System.out.println("***************************************************************");
		dbJavaF(studentAss, 2000);
		System.out.println("***************************************************************");
		System.out.println("********" + " Kyler's Code start here here: " + "**************");
		System.out.println("***************************************************************");
		System.out.println(" @@@@@@@@@@@@@@@@@@@@@@ ");
		System.out.println(" Big file Ends Here ");
		System.out.println(" @@@@@@@@@@@@@@@@@@@@@@ ");
		
		dbJavaG(studentPerList, 10);
		dbJavaH(studentAss, 2000);

		// here is to give us the total missing values:
		sampleSize.countNull("src/dbSampleSize/SampleSize/studentAssessment.csv");
		// avrage method call here:
	}

	public static void countNull(String fileName) {
		BufferedReader brr = null;
		String linee;
		int nullCounter = 0;
		try {
			brr = new BufferedReader(new FileReader(fileName));
			while ((linee = brr.readLine()) != null) {
				String[] databaseInputt = linee.split(",");
				for (int i = 0; i < databaseInputt.length; i++) {
					if (databaseInputt[i] == null)
						nullCounter++;
				}
				if (databaseInputt.length < 5)
					nullCounter++;
			}

			System.out.println("count of null values is " + nullCounter);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void dbJavaA(ArrayList<StudentPerformance> studentPerList) {
		System.out.println(" @@@@@@@@@@@@@@@@@@@@@@ ");
		System.out.println(" Small file Start Here ");
		System.out.println(" @@@@@@@@@@@@@@@@@@@@@@ ");
		System.out.println("***************************************************************");
		System.out.println("********" + " Sammer's Code Start here : " + "**************");
		System.out.println("***************************************************************");
		@SuppressWarnings("unused")
		Random randNumber = new Random();
		@SuppressWarnings("unused")
		int[] array = new int[50]; // sample size 50
		int gap = 1000 / 50; // for generating gap between two random numbers
		@SuppressWarnings("unused")
		int y, z = 1;
		for (int i = 0; i < studentPerList.size(); i += gap)
			System.out.println(studentPerList.get(i));
		System.out.println("***************************************************************");
		System.out.println("********" + " Sammer's Code Ends here : " + "**************");
		System.out.println("***************************************************************");

	}

	public static void dbJavaB(ArrayList<studentAssessment> studentAss) {
		System.out.println(" @@@@@@@@@@@@@@@@@@@@@@ ");
		System.out.println(" Big file Start Here ");
		System.out.println(" @@@@@@@@@@@@@@@@@@@@@@ ");
		System.out.println("***************************************************************");
		System.out.println("********" + " Sammer's Code Start here : " + "**************");
		System.out.println("***************************************************************");
		@SuppressWarnings("unused")
		Random randNumber = new Random();
		@SuppressWarnings("unused")
		int[] array = new int[2000]; // sample size 2000
		int gap = 173912 / 2000; // for generating gap between two random numbers
		@SuppressWarnings("unused")
		int y, z = 1;
		// int ctr=0;
		for (int i = 0; i < studentAss.size(); i += gap) {
			System.out.println(studentAss.get(i));
			// ctr++;
		}
		// System.out.println("total records are "+ ctr);
		System.out.println("***************************************************************");
		System.out.println("********" + " Sammer's Code Ends here: " + "**************");
		System.out.println("***************************************************************");

	}

	public static void dbJavaC(ArrayList<StudentPerformance> studentPerList, int n) {
		min += n;
		max += n;
		int randomNum = rand.nextInt((max - min) + 1) + min;
		if (randomNum > studentPerList.size()) {
			return;
		}
		if (n >= studentPerList.size()) {
			return;
		}
		System.out.println("***************************************************************");
		System.out.println("********" + " Justin's Code Start here: " + "**************");
		System.out.println("***************************************************************");
		System.out.println(studentPerList.get(randomNum));
		System.out.println("***************************************************************");
		System.out.println("********" + " Justin's Code End here: " + "**************");
		System.out.println("***************************************************************");

		if (n <= studentPerList.size()) {

		}
	}

	public static void dbJavaD(ArrayList<studentAssessment> studentAss, int n) {
		min += n;
		max += n;
		int randomNum = rand.nextInt((max - min) + 1) + min;
		if (randomNum > studentAss.size()) {
			return;
		}
		if (n >= studentAss.size()) {
			return;
		}

		System.out.println("***************************************************************");
		System.out.println("********" + " Justin's Code Start here: " + "**************");
		System.out.println("***************************************************************");
		System.out.println(studentAss.get(randomNum));
		System.out.println("***************************************************************");
		System.out.println("********" + " Justin's Code End here: " + "**************");
		System.out.println("***************************************************************");

		if (n <= studentAss.size()) {
		}

	}

	public static void dbJavaE(ArrayList<StudentPerformance> studentPerList, int sampleSize) {
		Collections.shuffle(studentPerList);
		for (int i = 0; i < sampleSize; i++) {
			System.out.println(studentPerList.get(i));

		}
	}

	public static void dbJavaF(ArrayList<studentAssessment> studentAss, int sampleSize) {
		for (int i = 0; i < sampleSize; i++) {
			if (studentAss.get(i).getScore() == -1) {
				sampleSize++;
			} else {

				System.out.println(studentAss.get(i));
			}
		}
	}

	public static void dbJavaG(ArrayList<StudentPerformance> studentPerList, int sampleSize) {

		ArrayList<StudentPerformance> groupA = new ArrayList<StudentPerformance>();
		ArrayList<StudentPerformance> groupB = new ArrayList<StudentPerformance>();
		ArrayList<StudentPerformance> groupC = new ArrayList<StudentPerformance>();
		ArrayList<StudentPerformance> groupD = new ArrayList<StudentPerformance>();
		ArrayList<StudentPerformance> groupE = new ArrayList<StudentPerformance>();

		for (StudentPerformance s : studentPerList) {
			if (s.getRace().equalsIgnoreCase("group a"))
				groupA.add(s);
			if (s.getRace().equalsIgnoreCase("group b"))
				groupB.add(s);
			if (s.getRace().equalsIgnoreCase("group c"))
				groupC.add(s);
			if (s.getRace().equalsIgnoreCase("group d"))
				groupD.add(s);
			if (s.getRace().equalsIgnoreCase("group e"))
				groupE.add(s);

		}

		System.out.println("***************************************************************");
		System.out.println("********" + " Cameren's Code Starts here: " + "**************");
		System.out.println("***************************************************************");

		recurse(0, sampleSize, groupA);
		System.out.println();
		recurse(0, sampleSize, groupB);
		System.out.println();
		recurse(0, sampleSize, groupC);
		System.out.println();
		recurse(0, sampleSize, groupD);
		System.out.println();
		recurse(0, sampleSize, groupE);
		System.out.println();
		
		System.out.println("***************************************************************");
		System.out.println("********" + " Cameren's Code Ends here: " + "**************");
		System.out.println("***************************************************************");
		
		
	}
	
	@SuppressWarnings("rawtypes")
	public static void dbJavaH(ArrayList studentAss, int sampleSize) {
		System.out.println("***************************************************************");
		System.out.println("********" + " Cameren's Big File Code Starts here: " + "*******");
		System.out.println("***************************************************************");
		
		recurse(0, 2000, studentAss);
		System.out.println("***************************************************************");
		System.out.println("********" + " Cameren's Code Ends here: " + "**************");
		System.out.println("***************************************************************");
		
	}
	
	@SuppressWarnings("rawtypes")
	public static int recurse(int num, int size, ArrayList list) {

		num++;// to get the 10 values

		// Continues recursing until it meets the size of the ArrayList
		while (num <= size) {
			printRecord(num, list); // calls print method
			recurse(num, size, list); // calls recurse method
			break;
		}
		return 0;
	}

	
	@SuppressWarnings("rawtypes")
	public static void printRecord(int j, ArrayList list) {

		Random rand = new Random();
		int randNum = rand.nextInt(list.size());
		System.out.println(list.get(randNum));
		

	}
}
